import { data } from 'cypress/types/jquery';
import xlsx from 'node-xlsx';

const XLSX = require("xlsx");

describe('update excel cell value', () => {


    it('read data from excel', () => {
        cy.parseXlsx('cypress/fixtures/batch2/excelData.xlsx').then( (jsonData) => {
            const rowLength = Cypress.$(jsonData[0].data).length;
            console.log("rowLength "+ rowLength);
            let employeeData = jsonData[0].data;
            //console.log("employeeData "+ employeeData)

            let today = new Date();
            const namePrefix = '-'+String(today.getMonth() + 1)+String(today.getDate())+String(today.getFullYear())
            console.log(namePrefix);
            let newExcelFile = [];
            for(let index = 0; index < rowLength-1; index++){
                let jsonData2 = employeeData[index][3];
                //let jsonData2 = employeeData[index].data;


                console.log(employeeData[index]);  
                if(index !== 0){         
                    
                    console.log("Index: " + index); 

                    employeeData[index][3] = employeeData[index][3].replace(/-.*/, namePrefix);
                    employeeData[index][4] = employeeData[index][4].replace(/-.*/, namePrefix);
                    
                    let newSalary = Math.floor(Math.random() * (5000 - 1000)) + 1000;                
                    employeeData[index][6] = newSalary;
                }                
                 
                

                newExcelFile.push([index, employeeData[index]])
                //cy.writeFile("cypress/fixtures/xlsxData.json", {co: employeeData[index][0], id: employeeData[index][1], 'Record Type': employeeData[index][2],
                //'First Name': employeeData[index][3], 'Last Name': employeeData[index][4], 'Cost Center 1': employeeData[index][5], 'Salary': employeeData[index][6],
                //'Dept/Pos Change Reason': employeeData[index][7], 'PayRate Change Reason': employeeData[index][8], AutoPay: employeeData[index][9]})
            }
            //let buffer = xlsx.build([{name: 'mySheetName', data: newExcelFile}]);

            //console.log("employeeData "+ newExcelFile.length)

            //cy.writeFile("cypress/fixtures/excelData2.xlsx", buffer)
           // xlsx.writeFile()

            
  const newWB = XLSX.utils.book_new();
  const newWS = XLSX.utils.json_to_sheet(employeeData);
  XLSX.utils.book_append_sheet(newWB, newWS, "EmployeeUpdate");
  
  const newfileName = "cypress/fixtures/EmployeeUpdate.xlsx";
  const saveAs = newfileName;

  //XLSX.writeFile(newWB, saveAs);

  //Cypress.env("downloadsFolder","cypress/fixtures/batch1");
  
  //XLSX.writeFile(newWB, "cypress/fixtures/batch1/EmployeeUpdate.xlsx");
  cy.task('saveXlsx', {file: newWB, filePath:"cypress/fixtures/batch2/excelData.xlsx"})



        })
    })

})