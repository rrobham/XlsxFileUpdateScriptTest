import { data } from 'cypress/types/jquery';
import xlsx from 'node-xlsx';

const XLSX = require("xlsx");
const Client = require('ftp');


describe('update excel cell value', () => {


    it('read data from excel', () => {
      
/*
        cy.getFilesList('cypress/fixtures/batch1').then( (files) => {
            cy.log(files.length)
            files.forEach(file => {
                console.log(file)
                
            })
        })
*/
       // console.log(Cypress.env('downloadsFolder'))
       // Cypress.env("downloadsFolder","cypress/fixtures/batch1");
       // console.log(Cypress.env('downloadsFolder'))
      
     
        cy.connectFTP("/workengineautomationtesting/drprod/cy").then((c) => {
     //       cy.log(c.length)
        });
        //.then( (files) => {
       // cy.log(files.length)
        
       //})
/*
        const ftpClient = new Client();
        ftpClient.on('ready', function() {       
            ftpClient.put('cypress/fixtures/batch1/excelData.xlsx', `workengineautomationtesting/drprod/cy/excelData.xlsx`, function(err) {
                if (err) throw err;
                ftpClient.end();
            });
        
        })  

        ftpClient.connect({keepalive: 30000, connTimeout: 30000, host: "qa-ftp-01.paylocity.com", user: "workengineautomationtesting", password: "CaldwellThrewElaineJourney68"});
*/

    })

})